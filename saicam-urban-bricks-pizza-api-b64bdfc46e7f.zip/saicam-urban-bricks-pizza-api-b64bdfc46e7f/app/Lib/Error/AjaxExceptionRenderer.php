<?php

App::uses('ExceptionRenderer', 'Error');

class AjaxExceptionRenderer extends ExceptionRenderer {
  /**
   * Overrided, to always use a bare controller.
   * 
   * @param Exception $exception The exception to get a controller for.
   * @return Controller
   */
  protected function _getController($exception) {
    if (!$request = Router::getRequest(true)) {
      $request = new CakeRequest();
    }
    $response = new CakeResponse(array('charset' => Configure::read('App.encoding'), 'type' => 'json'));
    $controller = new Controller($request, $response);
    $controller->viewPath = 'Errors/ajax';
    $controller->layout = 'ajax';
    return $controller;
  }
}

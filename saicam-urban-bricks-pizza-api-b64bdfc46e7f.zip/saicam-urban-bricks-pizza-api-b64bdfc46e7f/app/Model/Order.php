<?php

App::uses('AppModel', 'Model');
App::uses('HttpSocket', 'Network/Http');

class Order extends AppModel {

  public $belongsTo = array(
    'Location' => array(
      'counterCache' => 'orderCount',
      'foreignKey' => 'location'
    ),
    'User' => array(
      'counterCache' => 'orderCount',
      'foreignKey' => 'user'
    )
  );

  /*
  public $validate = array(
    'location' => array(
      'rule' => array(
        'notBlank'
      )
    ),
    'items' => array(
      'rule' => array(
        'notBlank'
      )
    ),
    'total' => array(
      'rule' => array(
        'notBlank'
      )
    ),
    'status' => array(
      'rule' => array(
        'notBlank'
      )
    )
  );

  public function afterSave($created = false, $options = array()) {
    if ($created) {
      if (!empty($this->data['Order']['user'])) {
        $this->User->id = $this->data['Order']['user'];
        $user = $this->User->findById($this->data['Order']['user']);
        if (!empty($user['User']['customs'])) {
          $customs = json_decode($user['User']['customs'], true);
        } else {
          $customs = array();
        }
        if (!empty($this->data['Order']['items'])) {
          $items = json_decode($this->data['Order']['items'], true);
          foreach($items as $item) {
            if (!empty($item['options']['name'])) {
              $customs[] = $item;
            }
          }
        }
        $customs = json_encode($customs);
        $this->User->saveField('customs', $customs);
      }
    }
    return true;
  }
  */

  public function revelOrder($options = array(), $type = 'order') {
    // Location
    $location = $this->Location->findById($options['Order']['location']);
    // Delivery
    $diningOption = 0;
    if ($options['Order']['delivery']) {
      $diningOption = 2;
    }
    // Items
    $revelItems = array();
    foreach($options['Order']['items'] as $item) {
      $modifieritems = array();
      foreach ($item['options'] as $modifier) {
        $modifieritems[] = array('modifier' => $modifier['id']);
      }
      $revelItems[] = array(
        'product' => $item['revelId'],
        'price' => $item['price'],
        'quantity' => $item['quantity'],
        'modifieritems' => $modifieritems
      );
    }
    // HttpSocket
    $HttpSocket = new HttpSocket();
    // Revel Headers
    $revelHeaders = array(
      'header' => array(
        'API-AUTHENTICATION' => Configure::read('app.source.revel.api.key').':'.Configure::read('app.source.revel.api.secret')
      )
    );
    // Dates
    $createdDatetime = new DateTime();
    $orderDatetime = new DateTime('2017-09-14 22:21:46'); // $options['Order']['orderTime'],
    // $this->log($datetime->format(DateTime::ATOM)); // 2017-08-26T20:34:01
    // Revel Cart Request
    $revelRequestData = array(
      'establishmentId' => $location['Location']['revelId'],
      'items' => $revelItems,
      'orderInfo' => array(
        'dining_option' => $diningOption,
        'created_date' => $createdDatetime->format(DateTime::ATOM),
        'pickup_time' => $orderDatetime->format(DateTime::ATOM),
        'notes' => $options['Order']['notes'],
        'asap' => false,
        'customer' => array(
          'phone' => $options['Order']['phone'],
          'email' => $options['Order']['email'],
          'first_name' => $options['Order']['firstName'],
          'last_name' => $options['Order']['lastName']
        ),
        'call_name' => $options['Order']['firstName'].' '.$options['Order']['lastName'].' / '.$orderDatetime->format('M j, g:ia').' / '.$options['Order']['phone']
      )
    );
    // Delivery
    if ($options['Order']['delivery']) {
      $revelRequestData['orderInfo']['customer']['address'] = array(
        'address' => $options['Order']['deliveryAddressStreet'].', '.$options['Order']['deliveryAddressStreet'].', '.$options['Order']['deliveryAddressStreet2'].', '.$options['Order']['deliveryAddressState'].', '.$options['Order']['deliveryAddressZip'],
        'city' => $options['Order']['deliveryAddressCity'],
        'country' => $options['Order']['deliveryAddressCountry'],
        // 'province' => $options['Order']['deliveryAddressState'],
        'state' => $options['Order']['deliveryAddressState'],
        'street_1' => $options['Order']['deliveryAddressStreet'],
        'street_2' => $options['Order']['deliveryAddressStreet2'],
        'zipcode' => $options['Order']['deliveryAddressZip']
      );
    }
    // CALCULATE
    if ($type == 'calculate') {
      // Revel Cart Calculate
      $revelCartCalculateURL = Configure::read('app.source.revel.api.url').'/specialresources/cart/calculate/';
      $revelCartCalculateResponse = $HttpSocket->post($revelCartCalculateURL, json_encode($revelRequestData), $revelHeaders);
      if ($revelCartCalculateResponse->code == 200) {
        $revelCartCalculateResponseBody = json_decode($revelCartCalculateResponse->body, true);
        if (!empty($revelCartCalculateResponseBody['status']) && $revelCartCalculateResponseBody['status'] == 'OK') {
          // Response
          $fResponse = array('success' => true, 'response' => $revelCartCalculateResponseBody);
          return $fResponse;
        } else {
          $this->log($revelCartCalculateResponse);
          // Response
          $fResponse = array('success' => false, 'response' => $revelCartCalculateResponseBody['error']['details']['message']);
          return $fResponse;
        }
      } else {
        $this->log($revelCartCalculateResponse);
        // Response
        $fResponse = array('success' => false, 'response' => 'Error on Revel Server');
        return $fResponse;
      }
    }
    // VALIDATE
    if ($type == 'validate') {
      // Add to Revel Object
      // $revelRequestData['skin'] = 'weborder';
      $revelRequestData['paymentInfo'] = array(
        'amount' => $options['Order']['total'],
        'tip' => 0,
        'tip_percent' => 0,
        'type' => 1 // Cash
      );
      // Credit Card
      if ($options['Order']['paymentType'] == 'card') {
        /* 2 is credit card BUT revel account needs to have payment processor setup */
        /* 4 is gift card */
        $revelRequestData['paymentInfo']['type'] = 4;
      }
      // Revel Cart Validate
      $revelCartValidateURL = Configure::read('app.source.revel.api.url').'/specialresources/cart/validate/';
      $revelCartValidateResponse = $HttpSocket->post($revelCartValidateURL, json_encode($revelRequestData), $revelHeaders);
      if ($revelCartValidateResponse->code == 200) {
        $revelCartValidateResponseBody = json_decode($revelCartValidateResponse->body, true);
        if (!empty($revelCartValidateResponseBody['status']) && $revelCartValidateResponseBody['status'] == 'OK') {
          // Credit Card
          if ($options['Order']['paymentType'] == 'card') {
            // Vantiv Mercury Pay Payment ID
            App::import('Vendor', 'Mercury/MercuryHCClient');
            $hcws = new MercuryHCClient(Configure::read('app.source.vantiv.merchantId'), Configure::read('app.source.vantiv.password'));
            $initPaymentRequest = array(
              // 'LaneID' => '02', // not needed
              'Invoice' => '139400', // NOT SURE HERE BECAUSE ITS NOT FINAL YET
              'TotalAmount'=> $options['Order']['total'],
              'TaxAmount' => $options['Order']['tax'],
              'TranType' => 'PreAuth',
              'Frequency' => 'OneTime',
              'Memo' => 'UrbanBricksPizzaAppV1',
              'ProcessCompleteUrl' => Configure::read('app.server.domain.cakephp').'/orders/paymentcomplete',
              'ReturnUrl' => Configure::read('app.server.domain.cakephp').'/orders/paymentcomplete'
            );
            // Staging
            if (Configure::read('app.server.mode') == 'staging') {
              $initPaymentRequest['OperatorID'] = 'Test';
            }
            $initPaymentResponse = $hcws->sendInitializePayment($initPaymentRequest);
            if ($initPaymentResponse->ResponseCode == 0 && !empty($initPaymentResponse->PaymentID)) {
              $revelCartValidateResponseBody['paymentId'] = $initPaymentResponse->PaymentID;
              // Response
              $fResponse = array('success' => true, 'response' => $revelCartValidateResponseBody);
              return $fResponse;
            } else {
              $this->log($initPaymentResponse);
              // Response
              $fResponse = array('success' => false, 'response' => $initPaymentResponse->Message);
              return $fResponse;
            }
          }
          // Cash
          if ($options['Order']['paymentType'] == 'cash') {
            // Response
            $fResponse = array('success' => true, 'response' => $revelCartValidateResponseBody);
            return $fResponse;
          }
        } else {
          $this->log($revelCartValidateResponse);
          // Response
          $fResponse = array('success' => false, 'response' => $revelCartValidateResponseBody['error']['details']['message']);
          return $fResponse;
        }
      } else {
        $this->log($revelCartValidateResponse);
        // Response
        $fResponse = array('success' => false, 'response' => 'Error on Revel Server');
        return $fResponse;
      }
    }
    // ORDER
    if ($type == 'submit') {
      // Add to Revel Object
      // $revelRequestData['skin'] = 'weborder';
      $revelRequestData['paymentInfo'] = array(
        'amount' => $options['Order']['total'],
        'tip' => 0,
        'tip_percent' => 0,
        'type' => 1 // Cash
      );
      // Credit Card
      if ($options['Order']['paymentType'] == 'card') {
        /* 2 is credit card BUT revel account needs to have payment processor setup */
        /* 4 is gift card */
        $revelRequestData['paymentInfo']['type'] = 2;
        $revelRequestData['paymentInfo']['transaction_id'] = $options['Order']['paymentTransactionId'];
      }
      // Revel Cart Submit
      $revelSubmitURL = Configure::read('app.source.revel.api.url').'/specialresources/cart/submit/';
      $this->log($revelRequestData);
      $revelSubmitResponse = $HttpSocket->post($revelSubmitURL, json_encode($revelRequestData), $revelHeaders);
      $this->log($revelSubmitResponse);
      if ($revelSubmitResponse->code == 200) {
        $revelSubmitResponseBody = json_decode($revelSubmitResponse->body, true);
        if (!empty($revelSubmitResponseBody['status']) && $revelSubmitResponseBody['status'] == 'OK') {
          // Success
          return $revelSubmitResponseBody;
        } else {
          $this->log($revelSubmitResponse);
          return false;
        }
      } else {
        $this->log($revelSubmitResponse);
        return false;
      }
    }
  }

}
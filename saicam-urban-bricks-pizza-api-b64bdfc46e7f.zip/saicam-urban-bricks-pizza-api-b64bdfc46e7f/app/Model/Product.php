<?php

App::uses('AppModel', 'Model');

class Product extends AppModel {

  public $displayField = 'title';

  public $belongsTo = array(
    'Location' => array(
      'counterCache' => 'productCount',
      'foreignKey' => 'location',
    )
  );

  public $validate = array(
    'title' => array(
      'rule' => array(
        'notBlank'
      )
    ),
    'status' => array(
      'rule' => array(
        'notBlank'
      )
    )
  );

}
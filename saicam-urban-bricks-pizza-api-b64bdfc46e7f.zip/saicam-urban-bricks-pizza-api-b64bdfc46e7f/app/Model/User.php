<?php

App::uses('AppModel', 'Model');
App::uses('AuthComponent', 'Controller/Component');

class User extends AppModel {

  public $displayField = 'email';

  public $hasMany = array(
    'Order' => array(
      'dependent' => true,
      'foreignKey' => 'user'
    )
  );

  public $validate = array(
    'firstName' => array(
      'rule' => array(
        'notBlank'
      ),
      'message' => 'Name is required'
    ),
    'email' => array(
      'isUnique' => array(
        'rule' => 'isUnique',
        'message' => 'Email already exists'
      )
    ),
    'password' => array(
      'rule' => array(
        'notBlank'
      ),
      'message' => 'Password required'
    ),
    'password_confirm' => array(
      'required' => array(
        'rule' => 'notBlank',
        'message' => 'Please confirm your password'
      ),
      'match' => array (
        'rule' => 'validatePasswordConfirm',
        'message' => 'Passwords do not match'
      )
    ),
    'facebookId' => array(
      'isUnique' => array(
        'rule' => 'isUnique',
        'message' => 'Facebook account already exists'
      )
    )
  );

  function validatePasswordConfirm($data) {
    if ($this->data[$this->alias]['password'] !== $data['password_confirm']) {
      return false;
    }
    return true;
  }

  public function beforeSave($options = array()) {
    if (isset($this->data[$this->alias]['password'])) {
      $this->data[$this->alias]['password'] = AuthComponent::password($this->data[$this->alias]['password']);
    }
    return true;
  }

}
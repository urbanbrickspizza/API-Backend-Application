<?php

App::uses('AppModel', 'Model');

class Location extends AppModel {

  public $displayField = 'title';

  public $hasMany = array(
    'Product' => array(
      'dependent' => true,
      'foreignKey' => 'location'
    )
  );

  public $validate = array(
    'title' => array(
      'rule' => array(
        'notBlank'
      )
    ),
    'status' => array(
      'rule' => array(
        'notBlank'
      )
    )
  );

}
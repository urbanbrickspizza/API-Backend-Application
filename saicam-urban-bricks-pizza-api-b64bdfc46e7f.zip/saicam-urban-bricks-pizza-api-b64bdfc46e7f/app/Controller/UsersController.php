<?php

App::uses('AppController', 'Controller');
App::uses('HttpSocket', 'Network/Http');

class UsersController extends AppController {

  public function beforeFilter() {
    parent::beforeFilter();
    // Security
    $this->Security->requireGet(array('view'));
    $this->Security->unlockedActions = array('add', 'edit', 'delete', 'qrcode', 'login', 'logout', 'checkemail', 'recover', 'otpregister', 'fbregister', 'addresscreate', 'addressdelivery', 'addressedit', 'addressdelete', 'addresslist', 'paymenttoken', 'paymentmethod', 'paymentcreate', 'paymentdelete', 'pastorders');
    // Auth
    $this->Auth->allow();
  }

  public function index() {
    // Find Users & Related Models
    $options = array();
    if (!empty($this->params['named']['filter'])) {
      $options = $this->params['named']['filter'];
    }
    $users = $this->findUsers($options);
    // Response
    $response = array(
      'data' => $users
    );
    return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
  }

  public function add() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // LevelUp
      $HttpSocket = new HttpSocket();
      // LevelUp Headers
      $levelUpHeaders = array(
        'header' => array(
          'Accept' => 'application/json',
          'Content-Type' => 'application/json'
        )
      );
      // Data
      $levelUpRequestData = array(
        'api_key' => 'HM3hpE9oh1Dd5S7YCmUEAQWT4GH8hpqpEeYAfzyJAWTwwi7ajuViLQjUnYEbmPMj',
        'user' => array(
          'email' => $this->request->data['user']['email'],
          'first_name' => $this->request->data['user']['firstName'],
          'last_name' => $this->request->data['user']['lastName'],
          // 'phone' => $this->request->data['user']['phone'],
          'password' => $this->request->data['user']['password']
        )
        /*,
        'permission_keynames' => array(
          'create_orders',
          'read_user_orders',
          'read_user_basic_info',
          'read_qr_code',
          'manage_user_campaigns',
          'manage_user_addresses',
          'manage_user_payment_methods'
        )
        */
      );
      $levelUpURL = 'https://api.thelevelup.com/v14/users';
      $levelUpURLResponse = $HttpSocket->post($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
      // $this->log($levelUpURLResponse);
      if ($levelUpURLResponse->code == 200) {
        return $levelUpURLResponse->body;
        /*
        // Set Password
        $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
        $accessToken = $levelUpURLResponseBody['access_token']['token'];
        // LevelUp
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        // Data
        $levelUpRequestData = array(
          'user' => array(
            'password' => $this->request->data['user']['password']
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/users';
        sleep(3);
        $levelUpURLResponse = $HttpSocket->put($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        $this->log($levelUpHeaders);
        $this->log($levelUpRequestData);
        $this->log($levelUpURLResponse);
        if ($levelUpURLResponse->code == 200) {
          return $levelUpURLResponse->body;
        } else {
          throw new InternalErrorException('Internal Error, try again');
        }
        */
      } elseif ($levelUpURLResponse->code == 422) {
        return $levelUpURLResponse->body;
      } else {
        throw new InternalErrorException('Internal Error, try again');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function fbregister() {
    // Post
    if ($this->request->is('post')) {
      App::import('Vendor', 'Facebook/autoload');
      $fb = new Facebook\Facebook([
        'app_id' => Configure::read('app.source.facebook.appId'),
        'app_secret' => Configure::read('app.source.facebook.secret'),
        'default_graph_version' => 'v2.2'
      ]);
      try {
        // Obtain User Token
        if (empty($this->request->data['access_token'])) {
          $fb_token_get = $this->cURLget('https://graph.facebook.com/oauth/access_token'
            . "?client_id=" . Configure::read('app.source.facebook.appId')
            . "&client_secret=". Configure::read('app.source.facebook.secret')
            . "&redirect_uri=" . urlencode(Configure::read('app.server.domain.ember').'/redirect')
            . "&code=" . $this->request->data['auth_code']
          );
          $fb_token_params = null;
          parse_str($fb_token_get,$fb_token_params);
          // $fb_token_params['access_token'];
          // $fb_token_params['expires'];
          $accessToken = $fb_token_params['access_token'];
          if (empty($accessToken)) {
            foreach($fb_token_params as $accessTokenKey => $accessTokenValue) {
              $accessTokenJSON = json_decode($accessTokenKey, true);
              $accessToken = $accessTokenJSON['access_token'];
            }
          }
        } else {
          $accessToken = $this->request->data['access_token'];
        }
        $fbResponse = $fb->get('/me?fields=id,first_name,last_name,email,birthday', $accessToken);
      } catch(Facebook\Exceptions\FacebookResponseException $e) {
        // Error Exception
        throw new InternalErrorException('Graph returned an error: ' . $e->getMessage());
      } catch(Facebook\Exceptions\FacebookSDKException $e) {
        // Error Exception
        throw new InternalErrorException('Facebook SDK returned an error: ' . $e->getMessage());
      }
      $fbUser = $fbResponse->getGraphUser();
      $user = $this->findUsers(array('facebookId' => $fbUser['id']));
      // Find By Email for prev created users
      if (empty($user) && !empty($fbUser['email'])) {
        $user = $this->findUsers(array('email' => $fbUser['email']));
        $userObject = $this->User->findByEmail($fbUser['email']);
        $this->User->id = $userObject['User']['id'];
        $this->User->saveField('facebookId', $fbUser['id']);
        $birthday = '';
        if (!empty($fbUser['birthday'])) {
          $this->User->saveField('birthday', $fbUser['birthday']->format('Y-m-d'));
        }
      }
      // Add User
      if (empty($user)) {
        $email = '';
        if (!empty($fbUser['email'])) {
          $email = $fbUser['email'];
        }
        $birthday = '';
        if (!empty($fbUser['birthday'])) {
          $birthday = $fbUser['birthday']->format('Y-m-d');
        }
        $userData['User'] = array(
          'facebookId' => $fbUser['id'],
          'firstName' => $fbUser['first_name'],
          'lastName' => $fbUser['last_name'],
          'email' => $email,
          'password' => $fbUser['id'],
          'birthday' => $birthday,
          'group' => 'user',
          'status' => 'active'
        );
        $this->User->set($userData);
        // Validate
        if ($this->User->validates()) {
          // Save
          if ($this->User->save()) {
            // Auth
            $user = $this->findUsers(array('id' => $this->User->id));
            // Send Email
          } else {
            // Error Exception
            throw new InternalErrorException('Saving error');
          }
        } else {
          // Error Exception
          $errors = $this->User->validationErrors;
          foreach ($errors as $field => $error) {
            throw new BadRequestException($error[0]);
          }
        }
      } else {
        $user = $user[0];
      }
      // Saved Response
      $response = array('user' => $user);
      return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
    }
  }

  public function view($id = null) {
    // Get User
    $accessToken = $this->request->header('UBP-User-Token');
    if (!empty($accessToken)) {
      // LevelUp
      $HttpSocket = new HttpSocket();
      // LevelUp Headers
      $levelUpHeaders = array(
        'header' => array(
          'Authorization' => 'token user="'.$accessToken.'"',
          'Accept' => 'application/json',
          'Content-Type' => 'application/json'
        )
      );
      $levelUpURL = 'https://api.thelevelup.com/v15/users';
      $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
      if ($levelUpURLResponse->code == 200) {
        $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
        // $response['token'] = $accessToken;
        $response['user'] = array(
          'id' => $levelUpURLResponseBody['user']['user_app_id'],
          'firstName' => $levelUpURLResponseBody['user']['first_name'],
          'lastName' => $levelUpURLResponseBody['user']['last_name'],
          'email' => $levelUpURLResponseBody['user']['email'],
          'phone' => $levelUpURLResponseBody['user']['phone'],
          'credit' => $levelUpURLResponseBody['user']['global_credit_amount']
        );
        // Get Address
        $levelUpURLAddress = 'https://api.thelevelup.com/v15/user_addresses';
        $levelUpURLAddressResponse = $HttpSocket->get($levelUpURLAddress, array(), $levelUpHeaders);
        if ($levelUpURLAddressResponse->code == 200) {
          $levelUpURLAddressResponseBody = json_decode($levelUpURLAddressResponse->body, true);
          if (!empty($levelUpURLAddressResponseBody)) {
            $response['user']['addressId'] = $levelUpURLAddressResponseBody[0]['user_address']['id'];
            $response['user']['addressType'] = $levelUpURLAddressResponseBody[0]['user_address']['address_type'];
            $response['user']['addressStreet'] = $levelUpURLAddressResponseBody[0]['user_address']['street_address'];
            $response['user']['addressStreet2'] = $levelUpURLAddressResponseBody[0]['user_address']['extended_address'];
            $response['user']['addressCity'] = $levelUpURLAddressResponseBody[0]['user_address']['locality'];
            $response['user']['addressState'] = $levelUpURLAddressResponseBody[0]['user_address']['region'];
            $response['user']['addressZip'] = $levelUpURLAddressResponseBody[0]['user_address']['postal_code'];
            $response['user']['addressZip'] = $levelUpURLAddressResponseBody[0]['user_address']['postal_code'];
          }
        }
        // Loyalty
        // $levelUpURLLoyalty = 'https://api.thelevelup.com/v15/merchants/320328/loyalty';
        $levelUpURLLoyalty = 'https://api.thelevelup.com/v15/campaigns/45241/spend_based_loyalty_v1';
        $levelUpURLLoyaltyResponse = $HttpSocket->get($levelUpURLLoyalty, array(), $levelUpHeaders);
        if ($levelUpURLLoyaltyResponse->code == 200) {
          $levelUpURLLoyaltyResponseBody = json_decode($levelUpURLLoyaltyResponse->body, true);
          if (!empty($levelUpURLLoyaltyResponseBody)) {
            $response['user']['loyalty'] = $levelUpURLLoyaltyResponseBody['campaign'];
            // Test $response['user']['loyalty']['spend_remaining_amount'] = 9000;
          }
        }
        return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
      } else {
        throw new InternalErrorException('Internal Error, try again');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function edit($id = null) {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('put')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        // Data
        $levelUpRequestData = array(
          'user' => array(
            'first_name' => $this->request->data['user']['firstName'],
            'last_name' => $this->request->data['user']['lastName'],
            'email' => $this->request->data['user']['email'],
            'phone' => $this->request->data['user']['phone']
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/users';
        $levelUpURLResponse = $HttpSocket->put($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
          // $response['token'] = $accessToken;
          $response['user'] = array(
            'id' => $levelUpURLResponseBody['user']['user_app_id'],
            'firstName' => $levelUpURLResponseBody['user']['first_name'],
            'lastName' => $levelUpURLResponseBody['user']['last_name'],
            'email' => $levelUpURLResponseBody['user']['email'],
            'phone' => $levelUpURLResponseBody['user']['phone'],
          );
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          throw new InternalErrorException('Internal Error, try again');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function qrcode() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/qr_codes';
        $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return $levelUpURLResponse->body;
        } else if ($levelUpURLResponse->code == 401) {
          // Error Exception
          throw new ForbiddenException('Unauthorized.');
        } else if ($levelUpURLResponse->code == 404) {
          // Error Exception
          throw new NotFoundException('Not found');
        } else if ($levelUpURLResponse->code == 422) {
          // Error Exception
          throw new BadRequestException('Payment preferences are invalid');
        } else {
          throw new InternalErrorException('Internal Error, try again');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function delete($id = null) {
    // Set User
    $this->User->id = $id;
    // Check if Exists
    if ($this->User->exists()) {
      if ($this->User->delete($id)) {
        // Saved Response
        $response = array(
          'data' => array(
            'success' => true
          )
        );
        return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
      } else {
        // Error Exception
        throw new InternalErrorException('Saving error');
      }
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function checkemail() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    if ($this->request->is('post')) {
      $email = $this->request->data['email'];
      // LevelUp
      $HttpSocket = new HttpSocket();
      // LevelUp Headers
      $levelUpHeaders = array(
        'header' => array(
          'Accept' => 'application/json',
          'Content-Type' => 'application/json'
        )
      );
      $levelUpURL = 'https://api.thelevelup.com/v15/registration?api_key=HM3hpE9oh1Dd5S7YCmUEAQWT4GH8hpqpEeYAfzyJAWTwwi7ajuViLQjUnYEbmPMj&email='.$email;
      $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
      if ($levelUpURLResponse->code == 200) {
        return $levelUpURLResponse->body;
      } elseif ($levelUpURLResponse->code == 404) {
        return $levelUpURLResponse->body;
      } else {
        throw new InternalErrorException('Internal Error, try again');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function recover() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    if ($this->request->is('post')) {
      $email = $this->request->data['email'];
      // LevelUp
      $HttpSocket = new HttpSocket();
      // LevelUp Headers
      $levelUpHeaders = array(
        'header' => array(
          'Accept' => 'application/json',
          'Content-Type' => 'application/json'
        )
      );
      // Data
      $levelUpRequestData = array(
        'email' => $email
      );
      $levelUpURL = 'https://api.thelevelup.com/v15/passwords';
      $levelUpURLResponse = $HttpSocket->post($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
      if ($levelUpURLResponse->code == 204) {
        $response = true;
        return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
      } elseif ($levelUpURLResponse->code == 422) {
        throw new NotFoundException('Not found');
      } else {
        throw new InternalErrorException('Internal Error, try again');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function otpregister($email, $ttl, $otp) {
    $this->autoRender = true;
    $this->layout = 'default';
    // Render
    if ($email) {
      $user = $this->User->findByEmail($email);
      if ($user) {
        $passwordHash = $user['User']['password'];
        $now = microtime(true);
        // check expiration date. the experation date should be greater them now.
        if ($now < $ttl) {
          // validate OTP
          if ($this->otpAuthenticate($otp, array('user' => $email, 'ttl' => $ttl))) {
            if ($this->request->data) {
              // set the password
              $password = $this->request->data['User']['password_new'];
              $this->User->id = $user['User']['id'];
              if ($this->request->data['User']['password_confirm_new'] != $password) {
                $this->Session->setFlash('Password and Confirmation password do not match. Please try again.', 'flash', array('type' => 'warning'));
              } else {
                $this->User->saveField('password', $password);
                if ($user['User']['group'] == 'admin') {
                  $this->redirect(Configure::read('app.server.domain.cms'));
                }
              }
            }
            $this->set('email', $email);
            $this->set('ttime', $ttl);
            $this->set('hash', $otp);
          } else {
            $this->Session->setFlash('Invalid request. Please contact the website administration.', 'flash', array('type' => 'warning'));
            $this->redirect(array('controller' => 'users', 'action' => 'message'));
          }
        } else {
          $this->Session->setFlash('Your invitation has expired. Please contact the website administration.', 'flash', array('type' => 'warning'));
          $this->redirect(array('controller' => 'users', 'action' => 'message'));
        }
      }
    }
  }

  public function login() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // LevelUp
      $HttpSocket = new HttpSocket();
      // LevelUp Headers
      $levelUpHeaders = array(
        'header' => array(
          'Accept' => 'application/json',
          'Content-Type' => 'application/json'
        )
      );
      // Data
      $levelUpRequestData = array(
        'access_token' => array(
          'api_key' => 'HM3hpE9oh1Dd5S7YCmUEAQWT4GH8hpqpEeYAfzyJAWTwwi7ajuViLQjUnYEbmPMj',
          'username' => $this->request->data['user']['email'],
          'password' => $this->request->data['user']['password']
        )
      );
      $levelUpURL = 'https://api.thelevelup.com/v15/access_tokens';
      $levelUpURLResponse = $HttpSocket->post($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
      if ($levelUpURLResponse->code == 200) {
        // Get User
        $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
        $accessToken = $levelUpURLResponseBody['access_token']['token'];
        // LevelUp
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/users';
        $levelUpURLResponse = $HttpSocket->get($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
          $response['token'] = $accessToken;
          $response['user'] = array(
            'id' => $levelUpURLResponseBody['user']['user_app_id'],
            'firstName' => $levelUpURLResponseBody['user']['first_name'],
            'lastName' => $levelUpURLResponseBody['user']['last_name'],
            'email' => $levelUpURLResponseBody['user']['email'],
            'phone' => $levelUpURLResponseBody['user']['phone'],
          );
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          throw new InternalErrorException('Internal Error, try again');
        }
      } elseif ($levelUpURLResponse->code == 422) {
        throw new ForbiddenException('Your email or password were incorrect');
      } else {
        throw new InternalErrorException('Internal Error, try again');
      }
    // Delete
    } else if ($this->request->is('delete')) {
      // Logout
      $this->Auth->logout();
      // Response
      $response = true;
      return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }
  
  public function logout() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Logout
    $this->Auth->logout();
    // Response
    $response = true;
    return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
  }

  public function register() {
    $this->request->data['User']['name'] = 'Admin';
    $this->request->data['User']['email'] = 'rudy@saicam.com';
    $this->request->data['User']['password'] = 'v4cH6map';
    $this->request->data['User']['user_group_id'] = 'admin';
    $this->request->data['User']['status'] = 'active';
    $this->User->save($this->request->data);
    // Response
    $response = true;
    return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
    
  }

  public function findUsers($params = null) {
    // Containable
    $this->User->Behaviors->attach('Containable', array('autoFields' => false));
    // Conditions
    $limit = 999;
    if (isset($params['limit']) && $params['limit']) {
      $limit = $params['limit'];
    }
    $conditions = array();
    if (isset($params['id']) && $params['id']) {
      $conditions['User.id'] = $params['id'];
    }
    if (isset($params['facebookId']) && $params['facebookId']) {
      $conditions['User.facebookId'] = $params['facebookId'];
    }
    if (isset($params['email']) && $params['email']) {
      $conditions['User.email'] = $params['email'];
    }
    if (isset($search) && $search) {
      $conditions['User.lastName LIKE'] = '%'.$search.'%';
    }
    // Paginate
    $options = array(
      'conditions' => $conditions,
      'contain' => array(
        'Order' => array(
          'fields' => array('id')
        )
      ),
      'limit' => $limit
    );
    // Set Data
    if (isset($params['id']) && $params['id']) {
      $user = $this->User->find('first', $options);
      $userId = $user['User']['id'];
      $userAttributes = array();
      foreach ($user['User'] as $attrKey => $attr) {
        if ($attrKey != 'id' && $attrKey != 'password') {
          $userAttributes[$this->camel2dashed($attrKey)] = $attr;
        }
      }
      $orders = array();
      foreach ($user['Order'] as $order) {
        $orders[] = array(
          'type' => 'orders',
          'id' => $order['id']
        );
      }
      $response = array(
        'type' => 'user',
        'id' => $userId,
        'attributes' => $userAttributes,
        'relationships' => array(
          'orders' => array(
            'data' => $orders
          )
        )
      );
    } else {
      $users = $this->User->find('all', $options);
      $response = array();
      foreach ($users as $key => $user) {
        $userId = $user['User']['id'];
        $userAttributes = array();
        foreach ($user['User'] as $attrKey => $attr) {
          if ($attrKey != 'id' && $attrKey != 'password') {
            $userAttributes[$this->camel2dashed($attrKey)] = $attr;
          }
        }
        $orders = array();
        foreach ($user['Order'] as $order) {
          $orders[] = array(
            'type' => 'orders',
            'id' => $order['id']
          );
        }
        $response[] = array(
          'type' => 'user',
          'id' => $userId,
          'attributes' => $userAttributes,
          'relationships' => array(
            'orders' => array(
              'data' => $orders
            )
          )
        );
      }
    }
    return $response;
  }

  public function addresslist() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/user_addresses';
        $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return $levelUpURLResponse->body;
        } else {
          throw new NotFoundException('No address found');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function addresscreate() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        // Data
        $levelUpRequestData = array(
          'user_address' => array(
            'address_type' => 'delivery',
            'street_address' => $this->request->data['addressStreet'],
            'extended_address' => $this->request->data['addressStreet2'],
            'locality' => $this->request->data['addressCity'],
            'region' => $this->request->data['addressState'],
            'postal_code' => $this->request->data['addressZip']
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/user_addresses';
        $levelUpURLResponse = $HttpSocket->post($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
          $response = array();
          if (!empty($levelUpURLResponseBody)) {
            $response['addressId'] = $levelUpURLResponseBody['user_address']['id'];
            $response['addressType'] = $levelUpURLResponseBody['user_address']['address_type'];
            $response['addressStreet'] = $levelUpURLResponseBody['user_address']['street_address'];
            $response['addressStreet2'] = $levelUpURLResponseBody['user_address']['extended_address'];
            $response['addressCity'] = $levelUpURLResponseBody['user_address']['locality'];
            $response['addressState'] = $levelUpURLResponseBody['user_address']['region'];
            $response['addressZip'] = $levelUpURLResponseBody['user_address']['postal_code'];
            $response['addressLatitude'] = $levelUpURLResponseBody['user_address']['latitude'];
            $response['addressLongitude'] = $levelUpURLResponseBody['user_address']['longitude'];
          }
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else if ($levelUpURLResponse->code == 422) {
          throw new InternalErrorException('Address type is invalid');
        } else {
          throw new InternalErrorException('Unable to add address');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function addressdelivery() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/user_addresses/'.$this->request->data['addressId'].'/delivery_location';
        $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
          if (!empty($levelUpURLResponseBody)) {
            $location['id'] = $levelUpURLResponseBody['location']['id'];
            $location['title'] = $levelUpURLResponseBody['location']['name'];
            $location['addressStreet'] = $levelUpURLResponseBody['location']['street_address'];
            $location['addressCity'] = $levelUpURLResponseBody['location']['locality'];
            $location['addressState'] = $levelUpURLResponseBody['location']['region'];
            $location['addressZip'] = $levelUpURLResponseBody['location']['postal_code'];
          }
          $response = array(
            'location' => $location
          );
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          throw new NotFoundException('There are no locations that deliver to this address.');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function addressedit() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        // Data
        $levelUpRequestData = array(
          'user_address' => array(
            'id' => $this->request->data['addressId'],
            'address_type' => $this->request->data['addressType'],
            'street_address' => $this->request->data['addressStreet'],
            'extended_address' => $this->request->data['addressStreet2'],
            'locality' => $this->request->data['addressCity'],
            'region' => $this->request->data['addressState'],
            'postal_code' => $this->request->data['addressZip']
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/user_addresses';
        $levelUpURLResponse = $HttpSocket->put($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          $response = true;
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          throw new NotFoundException('Address not found');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function addressdelete() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/user_addresses/'.$this->request->data['addressId'];
        $levelUpURLResponse = $HttpSocket->delete($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          $response = true;
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          throw new NotFoundException('Address not found');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function paymenttoken() {
    // Braintree
    App::import('Vendor', 'Braintree/lib/autoload');
    Braintree_Configuration::environment('sandbox');
    Braintree_Configuration::merchantId('m2xzdy53z7pkbcmy');
    Braintree_Configuration::publicKey('r89c2xvj8sfdxmhf');
    Braintree_Configuration::privateKey('8b242a89c271cfb4a54246921549a2a2');
    $response = array(
      'token' => Braintree_ClientToken::generate()
    );
    return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
  }

  public function paymentmethod() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/payment_method';
        $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return $levelUpURLResponse->body;
        } else {
          throw new NotFoundException('No payment method found');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function paymentcreate() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        // Data
        $levelUpRequestData = array(
          'credit_card' => array(
            'braintree_payment_nonce' => $this->request->data['paymentNonce']
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/credit_cards';
        $levelUpURLResponse = $HttpSocket->post($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return $levelUpURLResponse->body;
        } elseif ($levelUpURLResponse->code == 422) {
          throw new NotFoundException('The Credit Card was Invalid');
        } else {
          throw new InternalErrorException('Internal Error, try again');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function paymentdelete() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/payment_method';
        $levelUpURLResponse = $HttpSocket->delete($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          $response = true;
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          throw new NotFoundException('Credit card not found');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function pastorders() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/apps/orders';
        $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
        // return '[{"order":{"bundle_closed_at":null,"bundle_descriptor":"LevelUp*NedsFalafel","contribution_target_name":null,"created_at":"2014-05-05T12:33:41-04:00","identifier_from_merchant":"100010","location_id":3796,"location_extended_address":"Ste 400","location_locality":"Boston","location_postal_code":"02110","location_region":"MA","location_street_address":"1234 Main St","merchant_id":1234,"merchant_name":"Ned\'s Falafel Shop","refunded_at":null,"transacted_at":"2014-05-05T12:33:41-04:00","uuid":"a209dd40b6a001318b26125276c82bfa","balance_amount":0,"contribution_amount":null,"credit_applied_amount":10,"credit_earned_amount":0,"spend_amount":10,"tip_amount":0,"total_amount":10}}]';
        if ($levelUpURLResponse->code == 200) {
          return $levelUpURLResponse->body;
        } else {
          throw new NotFoundException('No orders found');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  function otpCreate($parameters) {
    return $this->Auth->password(implode('', $parameters));
  }

  function otpAuthenticate($otp, $parameters) {
    return $otp == $this->Auth->password(implode('', $parameters));
  }

  function cURLget($ch_url) {
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$ch_url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_USERAGENT,$_SERVER['HTTP_USER_AGENT']);
    $ch_send = curl_exec($ch);
    curl_close($ch);
    return $ch_send;
  }

}
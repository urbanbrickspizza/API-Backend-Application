<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package   app.Controller
 * @link    http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

  public $components = array('Auth', 'RequestHandler', 'Security', 'Session');
  public $helpers = array('Session');

  public function beforeFilter() {
    // Render
    $this->autoRender = false;
    $this->layout = 'ajax';
    // Authentication
    $this->Auth->authenticate = array('Form' => array('fields' => array('username' => 'email')));
    $this->Auth->authorize = array('Controller');
    $this->Auth->autoRedirect = false;
    $this->Auth->loginAction = Configure::read('app.server.domain.name');
    $this->Auth->logoutRedirect = array('controller' => 'users', 'action' => 'login');
    // CORS
    $ubpAuth = false;
    $headers = apache_request_headers();
    foreach ($headers as $header => $value) {
      if ($header == 'Ubp-Auth') {
        $ubpAuth = $value;
      }
    }
    if (!empty($_SERVER['HTTP_ORIGIN']) || !empty($ubpAuth)) {
      // Origin
      $allowedOrigins = Configure::read('app.server.corsAllowedDomains');
      $origin = (!empty($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '');
      // Authorization Header
      if (isset($ubpAuth) && Configure::read('app.server.authorization') == $ubpAuth) {
        $origin = '*';
        $allowedOrigins[] = $origin;
      }
      // Orgin
      foreach ($allowedOrigins as $allowedOrigin) {
        if (preg_match('#' . $allowedOrigin . '#', $origin)) {
          header('Access-Control-Allow-Origin: ' . $origin);
          header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
          if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            header("Accept: {$_SERVER['HTTP_ACCEPT']}");
            if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
              header("Access-Control-Allow-Methods: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']}");
            }
            if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
              header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
            }
          }
          break;
        }
      }
    } else {
      if (strpos($_SERVER['REQUEST_URI'], '/users/otpregister') !== false || strpos($_SERVER['REQUEST_URI'], '/orders/paymentcomplete') !== false) {
        // echo 'true';
      } else {
        throw new ForbiddenException('Unauthorized.');
      }
    }
    // Security
    $this->Security->requireGet('view');
    $this->Security->csrfCheck = false;
  }

  public function isAuthorized() {
    if ($this->Auth->user('group') == 'admin') return true;
    if (!empty($this->permissions[$this->action])) { 
      if ($this->permissions[$this->action] == '*') return true; 
      if (in_array($this->Auth->user('group'), $this->permissions[$this->action])) return true; 
    }
    return false;
  }

  public function utf8ize($d) {
    if (is_array($d)) {
      foreach ($d as $k => $v) {
        $d[$k] = $this->utf8ize($v);
      }
    } else if (is_string($d)) {
       return utf8_encode($d);
    }
    return $d;
  }

  public function camel2dashed($className) {
    return strtolower(preg_replace('/([a-zA-Z])(?=[A-Z])/', '$1-', $className));
  }

  public function dashed2camel($input) {
    return str_replace('-', '', lcfirst(ucwords($input, '-')));
  }

}

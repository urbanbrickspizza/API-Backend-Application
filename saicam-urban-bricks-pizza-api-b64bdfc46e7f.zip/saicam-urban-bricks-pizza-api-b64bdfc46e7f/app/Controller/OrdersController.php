<?php

App::uses('AppController', 'Controller');
App::uses('HttpSocket', 'Network/Http');

class OrdersController extends AppController {

  public function beforeFilter() {
    parent::beforeFilter();
    // Security
    $this->Security->requireGet(array('index', 'view'));
    $this->Security->unlockedActions = array('validateorder', 'validatestatus', 'proposed', 'proposedstatus', 'complete', 'completestatus', 'revelCalculate', 'revelValidate', 'paymentcomplete', 'add', 'detail', 'edit', 'delete');
    // Auth
    $this->Auth->allow();
  }

  public function index() {
    // Find Orders
    $orders = $this->findOrders($this->request->query);
    // Response
    $response = array(
      'data' => $orders
    );
    return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
  }

  public function revelCalculate() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Set Data
      $request = json_decode($this->request->input(), true);
      $revelCalculateResponse = $this->Order->revelOrder($request, 'calculate');
      if ($revelCalculateResponse['success']) {
        return json_encode($this->utf8ize($revelCalculateResponse['response']), JSON_NUMERIC_CHECK);
      } else {
        // Error Exception
        throw new InternalErrorException('Revel Systems error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function revelValidate() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Set Data
      $request = json_decode($this->request->input(), true);
      $revelValidateResponse = $this->Order->revelOrder($request, 'validate');
      if ($revelValidateResponse['success']) {
        return json_encode($this->utf8ize($revelValidateResponse['response']), JSON_NUMERIC_CHECK);
      } else {
        // Error Exception
        throw new InternalErrorException($revelValidateResponse['response']);
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function paymentcomplete() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Response
      if (!empty($this->request->data['PaymentID'])) {
        // Return response
        return '<script> window.parent.postMessage({paymentID: "'.$this->request->data['PaymentID'].'",returnCode: '.$this->request->data['ReturnCode'].',returnMessage: "'.$this->request->data['ReturnMessage'].'"}, "*"); </script>';
      } else {
        // Error Exception
        throw new NotFoundException('Not found');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function validateorder() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        // Data
        // Delivery
        $fulfillment_type = 'pickup';
        $delivery_address_id = null;
        if ($this->request->data['order']['delivery']) {
          $fulfillment_type = 'delivery';
          $delivery_address_id = $this->request->data['order']['deliveryAddressId'];
        }
        // Items
        $levelUpItems = array();
        foreach($this->request->data['order']['items'] as $item) {
          $modifieritems = array();
          foreach ($item['options'] as $modifier) {
            $modifieritems[] = $modifier['id'];
          }
          $instructions = '';
          if (!empty($item['instructions'])) {
            $instructions = $item['instructions'];
          }
          $levelUpItems[] = array(
            'item' => array(
              'id' => $item['id'],
              'quantity' => $item['quantity'],
              'special_instructions' => $instructions,
              'option_ids' => $modifieritems
            )
          );
        }
        $levelUpRequestData = array(
          'order' => array(
            'location_id' => $this->request->data['order']['location'],
            'conveyance' => array(
              'fulfillment_type' => $fulfillment_type,
              'desired_ready_time' => null,
              'delivery_address_id' => $delivery_address_id
            ),
            'items' => $levelUpItems,
            'special_instructions' => $this->request->data['order']['notes'],
            'tip_amount' => 0
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/order_ahead/orders';
        $levelUpURLResponse = $HttpSocket->post($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200 || $levelUpURLResponse->code == 202) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"validated":true}' );
        } else {
          throw new InternalErrorException('Unable to initiate order');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function validatestatus() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURLResponse = $HttpSocket->get($this->request->data['order_url'], array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"validated":true}' );
        } else if ($levelUpURLResponse->code == 202) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"validated":true}' );
        } else if ($levelUpURLResponse->code == 422) {
          $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
          throw new NotFoundException($levelUpURLResponseBody[0]['error']['message']);
        } else {
          throw new InternalErrorException('Unable to initiate order');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function proposed() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/order_ahead/orders/'.$this->request->data['uuid'];
        $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"proposed":true}' );
        } else {
          throw new InternalErrorException('Unable to get proposed order');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function complete() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/order_ahead/orders/'.$this->request->data['uuid'].'/complete';
        $levelUpURLResponse = $HttpSocket->post($levelUpURL, array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"completed":true}' );
        } else if ($levelUpURLResponse->code == 202) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"completed":true}' );
        } else {
          throw new InternalErrorException('Unable to get proposed order');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function completestatus() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        $levelUpURLResponse = $HttpSocket->get($this->request->data['order_url'], array(), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"completed":true}' );
        } else if ($levelUpURLResponse->code == 202) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"completed":true}' );
        } else if ($levelUpURLResponse->code == 422) {
          $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
          throw new NotFoundException($levelUpURLResponseBody[0]['error']['message']);
        } else {
          throw new InternalErrorException('Unable to initiate order');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function add() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Get User
      $accessToken = $this->request->header('UBP-User-Token');
      if (!empty($accessToken)) {
        // LevelUp
        $HttpSocket = new HttpSocket();
        // LevelUp Headers
        $levelUpHeaders = array(
          'header' => array(
            'Authorization' => 'token user="'.$accessToken.'"',
            'Accept' => 'application/json',
            'Content-Type' => 'application/json'
          )
        );
        // Data
        // Delivery
        $fulfillment_type = 'pickup';
        $delivery_address_id = null;
        if ($this->request->data['order']['delivery']) {
          $fulfillment_type = 'delivery';
          $delivery_address_id = $this->request->data['order']['deliveryAddressId'];
        }
        // Items
        $levelUpItems = array();
        foreach($this->request->data['order']['items'] as $item) {
          $modifieritems = array();
          foreach ($item['options'] as $modifier) {
            $modifieritems[] = $modifier['id'];
          }
          $notes = '';
          if (!empty($item['notes'])) {
            $notes = $item['notes'];
          }
          $levelUpItems[] = array(
            'id' => $item['id'],
            'quantity' => $item['quantity'],
            'special_instructions' => $notes,
            'option_ids' => $modifieritems
          );
        }
        $levelUpRequestData = array(
          'order' => array(
            'location_id' => $this->request->data['order']['location'],
            'conveyance' => array(
              'fulfillment_type' => $fulfillment_type,
              'desired_ready_time' => null,
              'delivery_address_id' => $delivery_address_id
            ),
            'items' => $levelUpItems,
            'special_instructions' => $this->request->data['order']['notes'],
            'tip_amount' => 0
          )
        );
        $levelUpURL = 'https://api.thelevelup.com/v15/order_ahead/ordersass';
        $levelUpURLResponse = $HttpSocket->post($levelUpURL, json_encode($levelUpRequestData), $levelUpHeaders);
        if ($levelUpURLResponse->code == 200) {
          return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"added":true}' );
        } else {
          throw new InternalErrorException('Unable to initiate order');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function detail($id = null) {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Get Order
    $accessToken = $this->request->header('UBP-User-Token');
    if (!empty($accessToken)) {
      // LevelUp
      $HttpSocket = new HttpSocket();
      // LevelUp Headers
      $levelUpHeaders = array(
        'header' => array(
          'Authorization' => 'token user="'.$accessToken.'"',
          'Accept' => 'application/json',
          'Content-Type' => 'application/json'
        )
      );
      $levelUpURL = 'https://api.thelevelup.com/v15/orders/'.$this->request->data['orderid'];
      $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
      //  return '{"order":{"bundle_closed_at":"2015-01-22T13:54:09-05:00","bundle_descriptor":"LevelUp*SampleMerchant","contribution_target_name":null,"created_at":"2015-01-22T13:54:07-05:00","id":523146,"identifier_from_merchant":"001001","location_id":19,"location_extended_address":"","location_latitude":42.36033,"location_locality":"Boston","location_longitude":-71.0589,"location_name":"","location_postal_code":"02114","location_region":"Massachusetts","location_street_address":"1234 Test Street","merchant_id":34,"merchant_name":"SampleMerchant","refunded_at":null,"transacted_at":"2015-01-22T13:54:07-05:00","uuid":"f7943600849501323c1552668b2aa48c","balance_amount":997,"contribution_amount":0,"credit_applied_amount":0,"credit_earned_amount":0,"spend_amount":997,"tax_amount":30,"tip_amount":0,"total_amount":997,"items":[{"item":{"category":"Breakfast Sides","description":"Shredded potatoes griddled to perfection","name":"Hashbrowns","quantity":1,"sku":"01abc192","upc":null,"child_items":[{"child_item":{"category":null,"description":"Scattered","name":"Special Instructions","quantity":1,"sku":null,"upc":null,"children":[],"charged_price_amount":0,"standard_price_amount":0}},{"child_item":{"category":null,"description":"Smothered","name":"Onions","quantity":1,"sku":null,"upc":null,"children":[],"charged_price_amount":50,"standard_price_amount":0}},{"child_item":{"category":null,"description":"Covered","name":"Cheese","quantity":2,"sku":null,"upc":null,"children":[],"charged_price_amount":100,"standard_price_amount":0}},{"child_item":{"category":null,"description":"Chunked","name":"Ham","quantity":1,"sku":null,"upc":null,"children":[],"charged_price_amount":50,"standard_price_amount":0}}],"charged_price_amount":299,"standard_price_amount":299}},{"item":{"category":"Drinks","description":"12oz Can of Coca-Cola","name":"Can Coke","quantity":2,"sku":"291soo01","upc":"04963406","children":[],"charged_price_amount":398,"standard_price_amount":199}}]}}';
      if ($levelUpURLResponse->code == 200) {
        return (!empty($levelUpURLResponse->body) ? $levelUpURLResponse->body : '{"detail":true}' );
      } else {
        throw new InternalErrorException('Internal Error, try again');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function view($id = null) {
    // Set Order
    $this->Order->id = $id;
    // Check if Exists
    if ($this->Order->exists()) {
      $order = $this->findOrders(array('id' => $id));
      $response = array(
        'data' => $order
      );
      return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function edit($id = null) {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Set Order
    $this->Order->id = $id;
    // Check if Exists
    if ($this->Order->exists()) {
      // Put
      if ($this->request->is('put')) {
        // Set Data
        $orderData['Order'] = $this->request->data['order'];
        $this->Order->set($orderData);
        // Validate
        if ($this->Order->validates()) {
          // Save
          if ($this->Order->save()) {
            // Saved Response
            $order = $this->findOrders(array('id' => $id));
            $response = array(
              'data' => $order
            );
            return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
          } else {
            // Error Exception
            throw new InternalErrorException('Saving error');
          }
        } else {
          // Error Exception
          throw new BadRequestException('Validation error');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function delete($id = null) {
    // Set Order
    $this->Order->id = $id;
    // Check if Exists
    if ($this->Order->exists()) {
      if ($this->Order->delete($id)) {
        // Saved Response
        $response = array(
          'data' => array(
            'success' => true
          )
        );
        return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
      } else {
        // Error Exception
        throw new InternalErrorException('Saving error');
      }
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function findOrders($params = null) {
    // Containable
    $this->Order->Behaviors->attach('Containable', array('autoFields' => false));
    // Conditions
    $limit = 999;
    if (isset($params['limit']) && $params['limit']) {
      $limit = $params['limit'];
    }
    $conditions = array();
    if (isset($params['id']) && $params['id']) {
      $conditions['Order.id'] = $params['id'];
    }
    if (isset($params['status']) && $params['status']) {
      $conditions['Order.status'] = $params['status'];
    }
    if (isset($search) && $search) {
      $conditions['Order.title LIKE'] = '%'.$search.'%';
    }
    // Paginate
    $options = array(
      'conditions' => $conditions,
      'contain' => array(
        'Location' => array(
          'fields' => array('id')
        ),
        'User' => array(
          'fields' => array('id')
        )
      ),
      'limit' => $limit
    );
    // Set Data
    if (isset($params['id']) && $params['id']) {
      $order = $this->Order->find('first', $options);
      $orderId = $order['Order']['id'];
      $orderAttributes = array();
      foreach ($order['Order'] as $attrKey => $attr) {
        if ($attrKey != 'id') {
          $orderAttributes[$this->camel2dashed($attrKey)] = $attr;
        }
      }
      $response = array(
        'type' => 'order',
        'id' => $orderId,
        'attributes' => $orderAttributes,
        'relationships' => array(
          'location' => array(
            'data' => array(
              'type' => 'location',
              'id' => $order['Location']['id']
            )
          ),
          'user' => array(
            'data' => array(
              'type' => 'user',
              'id' => $order['User']['id']
            )
          )
        )
      );
    } else {
      $orders = $this->Order->find('all', $options);
      $response = array();
      foreach ($orders as $key => $order) {
        $orderId = $order['Order']['id'];
        $orderAttributes = array();
        foreach ($order['Order'] as $attrKey => $attr) {
          if ($attrKey != 'id') {
            $orderAttributes[$this->camel2dashed($attrKey)] = $attr;
          }
        }
        $response = array(
          'type' => 'order',
          'id' => $orderId,
          'attributes' => $orderAttributes,
          'relationships' => array(
            'location' => array(
              'data' => array(
                'type' => 'location',
                'id' => $order['Location']['id']
              )
            ),
            'user' => array(
              'data' => array(
                'type' => 'user',
                'id' => $order['User']['id']
              )
            )
          )
        );
      }
    }
    return $response;
  }

}

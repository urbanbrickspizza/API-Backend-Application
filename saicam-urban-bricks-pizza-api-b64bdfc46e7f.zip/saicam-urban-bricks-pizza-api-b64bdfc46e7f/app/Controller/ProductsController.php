<?php

App::uses('AppController', 'Controller');

class ProductsController extends AppController {

  public function beforeFilter() {
    parent::beforeFilter();
    // Security
    $this->Security->requireGet(array('index', 'view'));
    $this->Security->unlockedActions = array('add', 'edit', 'delete');
    // Auth
    $this->Auth->allow();
  }

  public function index() {
    // Find Products
    $products = $this->findProducts($this->request->query);
    // Response
    $response = array(
      'data' => $products
    );
    return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
  }

  public function add() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Set Data
      $productData['Product'] = $this->request->data['product'];
      $this->Product->set($productData);
      // Validate
      if ($this->Product->validates()) {
        // Save
        if ($this->Product->save()) {
          // Saved Response
          $product = $this->findProducts(array('id' => $this->Product->id));
          $response = array(
            'data' => $product
          );
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          // Error Exception
          throw new InternalErrorException('Saving error');
        }
      } else {
        // Error Exception
        throw new BadRequestException('Validation error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function view($id = null) {
    // Set Product
    $this->Product->id = $id;
    // Check if Exists
    if ($this->Product->exists()) {
      $product = $this->findProducts(array('id' => $id));
      $response = array(
        'data' => $product
      );
      return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function edit($id = null) {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Set Product
    $this->Product->id = $id;
    // Check if Exists
    if ($this->Product->exists()) {
      // Put
      if ($this->request->is('put')) {
        // Set Data
        $productData['Product'] = $this->request->data['product'];
        $this->Product->set($productData);
        // Validate
        if ($this->Product->validates()) {
          // Save
          if ($this->Product->save()) {
            // Saved Response
            $product = $this->findProducts(array('id' => $id));
            $response = array(
              'data' => $product
            );
            return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
          } else {
            // Error Exception
            throw new InternalErrorException('Saving error');
          }
        } else {
          // Error Exception
          throw new BadRequestException('Validation error');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function delete($id = null) {
    // Set Product
    $this->Product->id = $id;
    // Check if Exists
    if ($this->Product->exists()) {
      if ($this->Product->delete($id)) {
        // Saved Response
        $response = array(
          'data' => array(
            'success' => true
          )
        );
        return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
      } else {
        // Error Exception
        throw new InternalErrorException('Saving error');
      }
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function findProducts($params = null) {
    // Containable
    $this->Product->Behaviors->attach('Containable', array('autoFields' => false));
    // Conditions
    $limit = 9999;
    if (isset($params['limit']) && $params['limit']) {
      $limit = $params['limit'];
    }
    $conditions = array();
    if (isset($params['id']) && $params['id']) {
      $conditions['Product.id'] = $params['id'];
    }
    if (isset($params['status']) && $params['status']) {
      $conditions['Product.status'] = $params['status'];
    }
    if (isset($search) && $search) {
      $conditions['Product.title LIKE'] = '%'.$search.'%';
    }
    // Paginate
    $options = array(
      'conditions' => $conditions,
      'limit' => $limit
    );
    // Set Data
    if (isset($params['id']) && $params['id']) {
      $product = $this->Product->find('first', $options);
      $productId = $product['Product']['id'];
      $productAttributes = array();
      foreach ($product['Product'] as $attrKey => $attr) {
        if ($attrKey != 'id') {
          $productAttributes[$this->camel2dashed($attrKey)] = $attr;
        }
      }
      $response = array(
        'type' => 'product',
        'id' => $productId,
        'attributes' => $productAttributes
      );
    } else {
      $products = $this->Product->find('all', $options);
      $response = array();
      foreach ($products as $key => $product) {
        $productId = $product['Product']['id'];
        $productAttributes = array();
        foreach ($product['Product'] as $attrKey => $attr) {
          if ($attrKey != 'id') {
            $productAttributes[$this->camel2dashed($attrKey)] = $attr;
          }
        }
        $response[] = array(
          'type' => 'products',
          'id' => $productId,
          'attributes' => $productAttributes
        );
      }
    }
    return $response;
  }

}

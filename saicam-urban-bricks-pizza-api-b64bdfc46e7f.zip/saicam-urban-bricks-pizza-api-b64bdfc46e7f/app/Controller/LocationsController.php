<?php

App::uses('AppController', 'Controller');
App::uses('HttpSocket', 'Network/Http');

class LocationsController extends AppController {

  public function beforeFilter() {
    parent::beforeFilter();
    // Security
    $this->Security->requireGet(array('index', 'view'));
    $this->Security->unlockedActions = array('add', 'edit', 'delete');
    // Auth
    $this->Auth->allow();
  }

  public function index() {
    // Find Locations
    /*
    $locations = $this->findLocations($this->request->query['page']);
    */
    $locations = [];
    $HttpSocket = new HttpSocket();
    // Revel Headers
    $levelUpHeaders = array(
      'header' => array(
        // 'Authorization' => 'token 184886-3Y63QZv5nNb1T91tfTV9tWMT2ePhvkbMhvPHdQtc5PoCVFnEfyKZ59hqkLdYtf',
        'Accept' => 'application/json',
        'Content-Type' => 'application/json'
      )
    );
    $levelUpURL = 'https://api.thelevelup.com/v15/apps/1147/locations';
    // Delivery
    if (isset($this->request->query['delivery'])) {
      $levelUpURL .= '?fulfillment_types=delivery&lat='.$this->request->query['latitude'].'&lng='.$this->request->query['longitude'].'&in_delivery_area=true';
    }
    $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
    if ($levelUpURLResponse->code == 200) {
      $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
      $levelUpURLResponseBodyResponse = array("locations" => array());
      foreach($levelUpURLResponseBody as $location) {
        $locationInfo = $location['location'];
        $locationInfo['id'] = $locationInfo['id'];
        $locationInfo['title'] = $locationInfo['name'];
        $locationInfo['addressStreet'] = $locationInfo['street_address'];
        $locationInfo['addressCity'] = $locationInfo['locality'];
        $locationInfo['addressState'] = $locationInfo['region'];
        $locationInfo['addressZip'] = $locationInfo['postal_code'];
        $locationInfo['geo'] = ['latitude' => $locationInfo['latitude'], 'longitude' => $locationInfo['longitude']];
        $locations[] = $locationInfo;
      }
      // Response
      $response = array(
        'locations' => $locations
      );
      return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
    } else if ($levelUpURLResponse->code == 204) {
      throw new NotFoundException('No locations found');
    } else {
      throw new InternalErrorException('Internal Error, try again');
    }
  }

  public function add() {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Post
    if ($this->request->is('post')) {
      // Set Data
      $locationData['Location'] = $this->request->data['location'];
      $this->Location->set($locationData);
      // Validate
      if ($this->Location->validates()) {
        // Save
        if ($this->Location->save()) {
          // Saved Response
          $location = $this->findLocations(array('id' => $this->Location->id));
          $response = array(
            'data' => $location
          );
          return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
        } else {
          // Error Exception
          throw new InternalErrorException('Saving error');
        }
      } else {
        // Error Exception
        throw new BadRequestException('Validation error');
      }
    } else {
      // Error Exception
      throw new MethodNotAllowedException('Method error');
    }
  }

  public function view($id = null) {
    // Location
    $location = [];
    // HttpSocket
    $HttpSocket = new HttpSocket();
    // Revel Headers
    $levelUpHeaders = array(
      'header' => array(
          // 'Authorization' => 'token 184886-3Y63QZv5nNb1T91tfTV9tWMT2ePhvkbMhvPHdQtc5PoCVFnEfyKZ59hqkLdYtf',
        'Accept' => 'application/json',
        'Content-Type' => 'application/json'
      )
    );
    $levelUpURL = 'https://api.thelevelup.com/v15/locations/'.$id;
    $levelUpURLResponse = $HttpSocket->get($levelUpURL, array(), $levelUpHeaders);
    $levelUpURLResponseBody = json_decode($levelUpURLResponse->body, true);
    $levelUpMenuURL = $levelUpURLResponseBody['location']['pickup_menu_url'];
    $levelUpMenuURLResponse = $HttpSocket->get($levelUpMenuURL, array(), $levelUpHeaders);
    // return print_r($levelUpURL);
    $levelUpMenuURLResponseBody = json_decode($levelUpMenuURLResponse->body, true);
    // Attributes
    $location['id'] = $levelUpURLResponseBody['location']['id'];
    $location['title'] = $levelUpURLResponseBody['location']['name'];
    $location['addressStreet'] = $levelUpURLResponseBody['location']['street_address'];
    $location['addressCity'] = $levelUpURLResponseBody['location']['locality'];
    $location['addressState'] = $levelUpURLResponseBody['location']['region'];
    $location['addressZip'] = $levelUpURLResponseBody['location']['postal_code'];
    $location['geo'] = ['latitude' => $levelUpURLResponseBody['location']['latitude'], 'longitude' => $levelUpURLResponseBody['location']['longitude']];
    $location['menu'] = [];
    // Menu
    foreach ($levelUpMenuURLResponseBody['menu']['categories'] as $mcKey => $menuCategory) {
      // ONLINE MENU
      $menuCategory = $menuCategory['category'];
      // Product Type
      $productType = '';
      switch($menuCategory['name']) {
        case 'Pizzas':
          $productType = 'pizza';
          $menuCategory['type'] = 'pizza';
          break;
        case 'Salads':
          $productType = 'salad';
          $menuCategory['type'] = 'salad';
          break;
        case 'Panini':
          $productType = 'panini';
          $menuCategory['type'] = 'panini';
          break;
        case 'Pastas':
          $productType = 'pasta';
          $menuCategory['type'] = 'pasta';
          break;
        case 'Wings':
          $productType = 'wing';
          $menuCategory['type'] = 'wing';
          break;
        case 'Side Chicks':
          $productType = 'wing';
          $menuCategory['type'] = 'wing';
          break;
        case 'Goodies':
          $productType = 'dessert';
          $menuCategory['type'] = 'dessert';
          break;
        case 'Drinks':
          $productType = 'drink';
          $menuCategory['type'] = 'drink';
          break;
      }
      if (!empty($menuCategory['items'])) {
        foreach ($menuCategory['items'] as $pKey => $product) {
          $product = $product['item'];
          // Product Type
          $menuCategory['items'][$pKey] = $product;
          $menuCategory['items'][$pKey]['type'] = $productType;
          // Image
          $menuCategory['items'][$pKey]['image'] = $productType.'-'.Inflector::slug(strtolower($product['name']),'-').'.jpg';
          // Form Options
          $menuCategory['items'][$pKey]['modifierForm'] = array();
          $modifier_classes = $product['option_groups'];
          if (!empty($modifier_classes)) {
            foreach ($modifier_classes as $mcKey => $modifierClass) {
              $modifierClass = $modifierClass['option_group'];
              // Modifier Class Type
              $modifierClassAdd = true;
              $modifierClassType = '';
              $modifierClassTypeSort = 0;
              // Build Your Own Pizza
              if ($product['name'] == 'Build Your Own Pizza') {
                switch($modifierClass['name']) {
                  case 'Mad Dough Options':
                    $modifierClassType = 'crust';
                    $modifierClassTypeSort = 1;
                    break;
                  case 'Sauce Options':
                    $modifierClassType = 'sauce';
                    $modifierClassTypeSort = 2;
                    break;
                  case 'Cheese Options':
                    $modifierClassType = 'cheese';
                    $modifierClassTypeSort = 3;
                    break;
                  case 'Protein Options':
                    $modifierClassType = 'protein';
                    $modifierClassTypeSort = 4;
                    break;
                  case 'Pre-Cheese Options':
                    $modifierClassType = 'veggie';
                    $modifierClassTypeSort = 5;
                    break;
                  case 'Veggie Options':
                    $modifierClassType = 'veggie';
                    $modifierClassTypeSort = 5;
                    break;
                  case 'Drizzle Options':
                    $modifierClassType = 'drizzle';
                    $modifierClassTypeSort = 6;
                    break;
                    /*
                  case 'Side Salad':
                    $modifierClassType = 'combo';
                    $modifierClassTypeSort = 7;
                    break;
                    */
                  default:
                    $modifierClassAdd = false;
                    break;
                }
              // Build Your Own Panini (Online)
              } else if ($product['name'] == 'Build Your Own Panini') {
                switch($modifierClass['name']) {
                  case 'Mad Dough Options':
                    $modifierClassType = 'crust';
                    $modifierClassTypeSort = 1;
                    break;
                  case 'Sauce Options':
                    $modifierClassType = 'sauce';
                    $modifierClassTypeSort = 2;
                    break;
                  case 'Cheese Options':
                    $modifierClassType = 'cheese';
                    $modifierClassTypeSort = 3;
                    break;
                  case 'Protein Options':
                    $modifierClassType = 'protein';
                    $modifierClassTypeSort = 4;
                    break;
                  case 'Pre-Cheese Options':
                    $modifierClassType = 'veggie';
                    $modifierClassTypeSort = 5;
                    break;
                  case 'Veggie Options':
                    $modifierClassType = 'veggie';
                    $modifierClassTypeSort = 5;
                    break;
                  case 'Drizzle Options':
                    $modifierClassType = 'drizzle';
                    $modifierClassTypeSort = 6;
                    break;
                  default:
                    $modifierClassAdd = false;
                    break;
                }
              // Build Your Own Salad
              } else if ($product['name'] == 'Build Your Own Salad') {
                switch($modifierClass['name']) {
                  case 'Full Size or Side Salad':
                    $modifierClassType = 'size';
                    $modifierClassTypeSort = 0;
                    break;
                  case 'Half or Full Salad':
                    $modifierClassType = 'size';
                    $modifierClassTypeSort = 0;
                    break;
                  case 'Green Options':
                    $modifierClassType = 'green';
                    $modifierClassTypeSort = 1;
                    break;
                  case 'Salad Veggies':
                    $modifierClassType = 'veggie';
                    $modifierClassTypeSort = 2;
                    break;
                  case 'Cheese Options':
                    $modifierClassType = 'cheese';
                    $modifierClassTypeSort = 3;
                    break;
                  case 'Salad Protein':
                    $modifierClassType = 'protein';
                    $modifierClassTypeSort = 4;
                    break;
                  case 'Salad Toppings':
                    $modifierClassType = 'topping';
                    $modifierClassTypeSort = 5;
                    break;
                  case 'Salad Dressings':
                    $modifierClassType = 'drizzle';
                    $modifierClassTypeSort = 6;
                    break;
                  default:
                    $modifierClassAdd = false;
                    break;
                }
              // General Products
              } else {
                switch($modifierClass['name']) {
                  case 'Full Size or Side Salad':
                    $modifierClassType = 'size';
                    $modifierClassTypeSort = 0;
                    break;
                  case 'Half or Full Salad':
                    $modifierClassType = 'size';
                    $modifierClassTypeSort = 0;
                    break;
                  case 'Mad Dough Options':
                    $modifierClassType = 'crust';
                    $modifierClassTypeSort = 1;
                    break;
                  case 'Green Options':
                    $modifierClassType = 'veggie';
                    $modifierClassTypeSort = 1;
                    break;
                  case 'Cheese Options':
                    $modifierClassType = 'cheese';
                    $modifierClassTypeSort = 2;
                    break;
                  case 'Salad Veggies':
                    $modifierClassType = 'veggie';
                    $modifierClassTypeSort = 4;
                    break;
                  case 'Salad Protein':
                    $modifierClassType = 'protein';
                    $modifierClassTypeSort = 5;
                    break;
                  case 'Drizzle Options':
                    $modifierClassType = 'drizzle';
                    $modifierClassTypeSort = 9;
                    break;
                  case 'Salad Dressings':
                    $modifierClassType = 'drizzle';
                    $modifierClassTypeSort = 9;
                    break;
                  default:
                    $modifierClassAdd = false;
                    break;
                }
              }
              // Add if added without approval
              if (!$modifierClassAdd && $modifierClass['minimum_choices'] > 0) {
                $modifierClassAdd = true;
                $modifierClassType = 'other';
                $modifierClassTypeSort = 0;
              }
              // If Ok to add Modifier Create Array
              if ($modifierClassAdd) {
                $modifiers = $modifierClass['options'];
                $modifierFormQuestion = array(
                  'name' => $modifierClass['name'],
                  'options' => array(),
                  'selectionName' => $modifierClassType,
                  'min' => $modifierClass['minimum_choices'],
                  'max' => $modifierClass['maximum_choices'],
                  'sort' => $modifierClassTypeSort
                );
                if (!empty($modifiers)) {
                  foreach ($modifiers as $moKey => $modifier) {
                    $modifier = $modifier['option'];
                    $modifier['type'] = $modifierClassType;
                    $modifier['image'] = $modifierClassType.'-'.Inflector::slug(strtolower($modifier['name']),'-').'.jpg';
                    $modifierFormQuestion['options'][] = $modifier;
                  }
                }
                // Form Options
                $menuCategory['items'][$pKey]['modifierForm'][] = $modifierFormQuestion;
              }
            }
            // Build Your Own Pizza
            if ($product['name'] == 'Build Your Own Pizza') {
              // Merge Vegies with Pre-Cheese
              $preCheese = null;
              $veggie = null;
              foreach($menuCategory['items'][$pKey]['modifierForm'] as $mfqKey => $mfqValue) {
                if ($mfqValue['name'] == 'Pre-Cheese Options') {
                  $preCheese = array('key' => $mfqKey, 'value' => $mfqValue);
                }
                if ($mfqValue['name'] == 'Veggie Options') {
                  $veggie = array('key' => $mfqKey, 'value' => $mfqValue);
                }
              }
              unset($menuCategory['items'][$pKey]['modifierForm'][$preCheese['key']]);
              if (is_array($preCheese) && is_array($veggie)) {
                $newVeggieOptionsArray = array_merge($preCheese['value']['options'], $veggie['value']['options']);
                $veggie['value']['max'] = count($newVeggieOptionsArray) - 1;
                $veggie['value']['options'] = $newVeggieOptionsArray;
                $menuCategory['items'][$pKey]['modifierForm'][$veggie['key']] = $veggie['value'];
              }
            }
            // Build Your Own Pizza
            if ($product['name'] == 'Build Your Own Panini') {
              // Merge Vegies with Pre-Cheese
              $preCheese = null;
              $veggie = null;
              foreach($menuCategory['items'][$pKey]['modifierForm'] as $mfqKey => $mfqValue) {
                if ($mfqValue['name'] == 'Pre-Cheese Options') {
                  $preCheese = array('key' => $mfqKey, 'value' => $mfqValue);
                }
                if ($mfqValue['name'] == 'Veggie Options') {
                  $veggie = array('key' => $mfqKey, 'value' => $mfqValue);
                }
              }
              unset($menuCategory['items'][$pKey]['modifierForm'][$preCheese['key']]);
              if (is_array($preCheese) && is_array($veggie)) {
                $newVeggieOptionsArray = array_merge($preCheese['value']['options'], $veggie['value']['options']);
                $veggie['value']['max'] = count($newVeggieOptionsArray) - 1;
                $veggie['value']['options'] = $newVeggieOptionsArray;
                $menuCategory['items'][$pKey]['modifierForm'][$veggie['key']] = $veggie['value'];
              }
            }
            // Reorder Modifiers
            if (!empty($menuCategory['items'][$pKey]['modifierForm'])) {
              $sortOrder = array();
              foreach ($menuCategory['items'][$pKey]['modifierForm'] as $key => $row) {
                $sortOrder[$key] = $row['sort'];
              }
              array_multisort($sortOrder, SORT_ASC, $menuCategory['items'][$pKey]['modifierForm']);
            }
          }
        }
      }
      // Add to menu
      $location['menu']['categories'][] = $menuCategory;
    }
    $response = array(
      'location' => $location
    );
    return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
  }

  public function edit($id = null) {
    if ($this->request->is('options')) {
      return json_encode(array(true));
    }
    // Set Location
    $this->Location->id = $id;
    // Check if Exists
    if ($this->Location->exists()) {
      // Put
      if ($this->request->is('put')) {
        // Set Data
        $locationData['Location'] = $this->request->data['location'];
        $this->Location->set($locationData);
        // Validate
        if ($this->Location->validates()) {
          // Save
          if ($this->Location->save()) {
            // Saved Response
            $location = $this->findLocations(array('id' => $id));
            $response = array(
              'data' => $location
            );
            return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
          } else {
            // Error Exception
            throw new InternalErrorException('Saving error');
          }
        } else {
          // Error Exception
          throw new BadRequestException('Validation error');
        }
      } else {
        // Error Exception
        throw new MethodNotAllowedException('Method error');
      }
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function delete($id = null) {
    // Set Location
    $this->Location->id = $id;
    // Check if Exists
    if ($this->Location->exists()) {
      if ($this->Location->delete($id)) {
        // Saved Response
        $response = array(
          'data' => array(
            'success' => true
          )
        );
        return json_encode($this->utf8ize($response), JSON_NUMERIC_CHECK);
      } else {
        // Error Exception
        throw new InternalErrorException('Saving error');
      }
    } else {
      // Error Exception
      throw new NotFoundException('Not found');
    }
  }

  public function findLocations($params = null) {
    // Containable
    $this->Location->Behaviors->attach('Containable', array('autoFields' => false));
    // Conditions
    $limit = 9999;
    if (isset($params['limit']) && $params['limit']) {
      $limit = $params['limit'];
    }
    $conditions = array();
    if (isset($params['id']) && $params['id']) {
      $conditions['Location.id'] = $params['id'];
    }
    if (isset($params['status']) && $params['status']) {
      $conditions['Location.status'] = $params['status'];
    }
    if (isset($search) && $search) {
      $conditions['Location.title LIKE'] = '%'.$search.'%';
    }
    // Paginate
    $options = array(
      'conditions' => $conditions,
      'contain' => array(
        'Product' => array(
          'conditions' => array('Product.status' => 'published'),
          'fields' => array('id')
        )
      ),
      'limit' => $limit
    );
    // Set Data
    if (isset($params['id']) && $params['id']) {
      $location = $this->Location->find('first', $options);
      $locationId = $location['Location']['id'];
      $locationAttributes = array();
      foreach ($location['Location'] as $attrKey => $attr) {
        if ($attrKey != 'id') {
          $locationAttributes[$this->camel2dashed($attrKey)] = $attr;
        }
      }
      $products = array();
      foreach ($location['Product'] as $product) {
        $products[] = array(
          'type' => 'products',
          'id' => $product['id']
        );
      }
      $response = array(
        'type' => 'location',
        'id' => $locationId,
        'attributes' => $locationAttributes,
        'relationships' => array(
          'products' => array(
            'data' => $products
          )
        )
      );
    } else {
      $locations = $this->Location->find('all', $options);
      $response = array();
      foreach ($locations as $key => $location) {
        $locationId = $location['Location']['id'];
        $locationAttributes = array();
        foreach ($location['Location'] as $attrKey => $attr) {
          if ($attrKey != 'id') {
            $locationAttributes[$this->camel2dashed($attrKey)] = $attr;
          }
        }
        $products = array();
        foreach ($location['Product'] as $product) {
          $products[] = array(
            'type' => 'products',
            'id' => $product['id']
          );
        }
        $response[] = array(
          'type' => 'locations',
          'id' => $locationId,
          'attributes' => $locationAttributes,
          'relationships' => array(
            'products' => array(
              'data' => $products
            )
          )
        );
      }
    }
    return $response;
  }

}

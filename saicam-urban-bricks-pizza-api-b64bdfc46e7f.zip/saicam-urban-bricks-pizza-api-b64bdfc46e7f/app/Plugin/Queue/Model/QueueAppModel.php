<?php
App::uses('AppModel', 'Model');

class QueueAppModel extends AppModel {
}


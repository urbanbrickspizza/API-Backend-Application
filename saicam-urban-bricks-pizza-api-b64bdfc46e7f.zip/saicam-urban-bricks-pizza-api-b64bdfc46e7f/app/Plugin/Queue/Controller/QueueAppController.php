<?php
App::uses('AppController', 'Controller');

class QueueAppController extends AppController {
}


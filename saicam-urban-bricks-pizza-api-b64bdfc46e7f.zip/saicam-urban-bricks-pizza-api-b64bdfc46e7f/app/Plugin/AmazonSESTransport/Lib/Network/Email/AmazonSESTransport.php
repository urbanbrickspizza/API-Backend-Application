<?php
/** 
 * Send mail using Amazon SES service
 *
 * This depends on AWS SDK for PHP (https://github.com/amazonwebservices/aws-sdk-for-php.git).
 *
 * @copyright Copyright 2012 News2u Corporation
 * @link http://www.news2u.co.jp/
 * @since CakePHP v2.0.0
 * @license MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
App::uses('AbstractTransport', 'Network/Email');
App::import('Vendor', 'AWS/aws-autoloader');
use Aws\Ses\SesClient;

/**
 * Send mail using Amazon SES service
 * 
 * @package Cake
 * @subpackage Lib.Network.Email
 */
class AmazonSESTransport extends AbstractTransport {

  /**
   * Send mail
   *
   * @param CakeEmail $email CakeEmail
   * @return array
   * @throws SocketException When mail cannot be sent.
   */
	public function send(CakeEmail $email) {
    // CakeEmail
    $this->_cakeEmail = $email;
    // AWS Connect
    $client = SesClient::factory(array(
      'credentials' => array(
        'key' => $this->_config['Amazon.SES.Key'],
        'secret' => $this->_config['Amazon.SES.Secret']
      ),
      'region' => $this->_config['Amazon.SES.Region'],
      'version' => $this->_config['Amazon.SES.Version']
    ));
    // Const
    $htmlContent = str_replace(array("\r","\n"),"",$this->_cakeEmail->message('html'));
    // $this->_config = $this->_cakeEmail->config();
    // $this->_headers = $this->_cakeEmail->getHeaders();
    // AWS Message Options
    $awsOptions = array(
      // Source is required
      'Source' => $this->_config['Amazon.SES.Source'],
      'Destination' => array(
        'ToAddresses' => array(),
        'CcAddresses' => array(),
        'BccAddresses' => array(),
      ),
      // Message is required
      'Message' => array(
        // Subject is required
        'Subject' => array(
          // Data is required
          'Data' => $this->_cakeEmail->subject()
        ),
        // Body is required
        'Body' => array(
          'Text' => array(
            // Data is required
            'Data' => 'UBP'
          ),
          'Html' => array(
            // Data is required
            'Data' => $htmlContent
          )
        )
      )
    );
    // To
    foreach ($this->_cakeEmail->to() as $email) {
      $awsOptions['Destination']['ToAddresses'][] = $email;
    }
    // Send
    return $client->sendEmail($awsOptions);
    /*
    if ($result->status != 200) {
      CakeLog::write('error', var_export($res,1));
      throw new SocketException(__d('cake_dev', 'Could not send email.'));
    }
    return $result; */
	}
}

<?php
/**
 * @author MGriesbach@gmail.com
 * @license http://www.opensource.org/licenses/mit-license.php The MIT License
 * @link http://github.com/MSeven/cakephp_queue
 */
App::uses('QueueTask', 'Queue.Console/Command/Task');
App::uses('HttpSocket', 'Network/Http');

/**
 * A Simple QueueTask example.
 *
 */
class QueueRevelSystemsSyncTask extends QueueTask {

/**
 * ZendStudio Codecomplete Hint
 *
 * @var QueuedTask
 */
  public $QueuedTask;

/**
 * Timeout for run, after which the Task is reassigned to a new worker.
 *
 * @var int
 */
  public $timeout = 10;

/**
 * Number of times a failed instance of this task should be restarted before giving up.
 *
 * @var int
 */
  public $retries = 1;

/**
 * Stores any failure messages triggered during run()
 *
 * @var string
 */
  public $failureMessage = '';

/**
 * Example add functionality.
 * Will create one example job in the queue, which later will be executed using run();
 *
 * @return void
 */
  public function add() {
    if ($this->QueuedTask->createJob('RevelSystemsSync', null)) {
      $this->out('OK, job created, now run the worker');
    } else {
      $this->err('Could not create Job');
    }
  }

/**
 * Example run function.
 * This function is executed, when a worker is executing a task.
 * The return parameter will determine, if the task will be marked completed, or be requeued.
 *
 * @param array $data The array passed to QueuedTask->createJob()
 * @param int $id The id of the QueuedTask
 * @return bool Success
 */
  public function run($data, $id = null) {
    try {
      // HttpSocket
      $HttpSocket = new HttpSocket();
      // Revel Headers
      $revelHeaders = array(
        'header' => array(
          'API-AUTHENTICATION' => Configure::read('app.source.revel.api.key').':'.Configure::read('app.source.revel.api.secret')
        )
      );
      // Location Model
      $LocationModel = ClassRegistry::init('Location');
      $LocationModel->Behaviors->attach('Containable', array('autoFields' => false));
      // Options
      $options = array(
        // 'conditions' => $conditions,
        'contain' => array(
          'Product'
        ),
        'limit' => 99
      );
      $locations = $LocationModel->find('all', $options);
      // Loop through Locations
      foreach ($locations as $lkey => $location) {
        // Location Data
        $locationData = array();
        // Revel Establishment Settings
        $revelEstablishmentSettingsURL = Configure::read('app.source.revel.api.url').'/weborders/system_settings/?establishment='.$location['Location']['revelId'];
        $revelEstablishmentSettingsResponse = $HttpSocket->get($revelEstablishmentSettingsURL, $revelHeaders);
        if ($revelEstablishmentSettingsResponse->code == 200) {
          $revelEstablishmentSettingsResponseBody = json_decode($revelEstablishmentSettingsResponse->body, true);
          if (!empty($revelEstablishmentSettingsResponseBody['status']) && $revelEstablishmentSettingsResponseBody['status'] == 'OK') {
            $locationData['Location']['revelSettings'] = json_encode($revelEstablishmentSettingsResponseBody['data']);
          }
        } else {
          $this->out('HTTP URL: '.$revelEstablishmentSettingsURL);
          $this->out('HTTP Resonse Code: '.$revelEstablishmentSettingsResponse->code);
        }
        // Revel Establishment Menu
        $revelMenuData = array();
        $revelEstablishmentMenuURL = Configure::read('app.source.revel.api.url').'/weborders/menu/?establishment='.$location['Location']['revelId'];
        $revelEstablishmentMenuResponse = $HttpSocket->get($revelEstablishmentMenuURL, $revelHeaders);
        if ($revelEstablishmentMenuResponse->code == 200) {
          $revelEstablishmentMenuResponseBody = json_decode($revelEstablishmentMenuResponse->body, true);
          if (!empty($revelEstablishmentMenuResponseBody['status']) && $revelEstablishmentMenuResponseBody['status'] == 'OK') {
            $revelEstablishmentMenu = $revelEstablishmentMenuResponseBody['data'];
            if (!empty($revelEstablishmentMenu['categories'])) {
              foreach ($revelEstablishmentMenu['categories'] as $mcKey => $menuCategory) {
                // ONLINE MENU
                if ($menuCategory['parent_name'] == 'ONLINE MENU') {
                  // Product Type
                  $productType = '';
                  switch($menuCategory['name']) {
                    case 'Pizzas':
                      $productType = 'pizza';
                      $menuCategory['type'] = 'pizza';
                      break;
                  }
                  if (!empty($menuCategory['products'])) {
                    foreach ($menuCategory['products'] as $pKey => $product) {
                      // Product Type
                      $menuCategory['products'][$pKey]['type'] = $productType;
                      // Image
                      $menuCategory['products'][$pKey]['image'] = $productType.'-'.Inflector::slug(strtolower($product['name']),'-').'.jpg';
                      // Form Options
                      $menuCategory['products'][$pKey]['modifierForm'] = array();
                      $modifier_classes = $product['modifier_classes'];
                      if (!empty($modifier_classes)) {
                        foreach ($modifier_classes as $mcKey => $modifierClass) {
                          // Modifier Class Type
                          $modifierClassAdd = true;
                          $modifierClassType = '';
                          $modifierClassTypeSort = 0;
                          // Build Your Own Pizza
                          if ($product['name'] == 'Build Your Own Pizza') {
                            switch($modifierClass['name']) {
                              case 'Pizza Crust Options':
                                $modifierClassType = 'crust';
                                $modifierClassTypeSort = 1;
                                break;
                              case 'Pizza Sauce Options':
                                $modifierClassType = 'sauce';
                                $modifierClassTypeSort = 2;
                                break;
                              case 'Cheese Options':
                                $modifierClassType = 'cheese';
                                $modifierClassTypeSort = 3;
                                break;
                              case 'Pizza Protein Options':
                                $modifierClassType = 'protein';
                                $modifierClassTypeSort = 4;
                                break;
                              case 'Pizza Pre-Cheese Options':
                                $modifierClassType = 'veggie';
                                $modifierClassTypeSort = 5;
                                break;
                              case 'Pizza Veggie Options':
                                $modifierClassType = 'veggie';
                                $modifierClassTypeSort = 5;
                                break;
                              case 'Pizza Drizzle Options':
                                $modifierClassType = 'drizzle';
                                $modifierClassTypeSort = 6;
                                break;
                            }
                          }
                          // Foundationa Pizza
                          if ($product['name'] == 'Urban Classic') {
                            switch($modifierClass['name']) {
                              case 'Pizza Crust Options':
                                $modifierClassType = 'crust';
                                $modifierClassTypeSort = 1;
                                break;
                              case 'Pizza Drizzle Options':
                                $modifierClassType = 'drizzle';
                                $modifierClassTypeSort = 2;
                                break;
                              default:
                                $modifierClassAdd = false;
                                break;
                            }
                          }
                          // If Ok to add Modifier Create Array
                          if ($modifierClassAdd) {
                            $modifiers = $modifierClass['modifiers'];
                            $modifierFormQuestion = array(
                              'name' => $modifierClass['name'],
                              'options' => array(),
                              'selectionName' => $modifierClassType,
                              'min' => $modifierClass['minimum_amount'],
                              'max' => $modifierClass['maximum_amount'],
                              'sort' => $modifierClassTypeSort
                            );
                            if (!empty($modifiers)) {
                              foreach ($modifiers as $moKey => $modifier) {
                                $modifier['type'] = $modifierClassType;
                                $modifier['image'] = $modifierClassType.'-'.Inflector::slug(strtolower($modifier['name']),'-').'.jpg';
                                $modifierFormQuestion['options'][] = $modifier;
                              }
                            }
                          }
                          // Build Your Own Pizza
                          if ($product['name'] == 'Build Your Own Pizza') {
                            // Merge Vegies with Pre-Cheese
                            if ($modifierClassType == 'veggie') {
                              $mfqVeggieKey = '';
                              foreach($menuCategory['products'][$pKey]['modifierForm'] as $mfqKey => $mfqValue) {
                                if ($mfqValue['selectionName'] == 'veggie') {
                                  $mfqVeggieKey = $mfqKey;
                                }
                              }
                              if (!empty($mfqVeggieKey)) {
                                $menuCategory['products'][$pKey]['modifierForm'][$mfqVeggieKey]['name'] = 'Pizza Veggie Options';
                                $newVeggieOptionsArray = array_merge($menuCategory['products'][$pKey]['modifierForm'][$mfqVeggieKey]['options'], $modifierFormQuestion['options']);
                                $menuCategory['products'][$pKey]['modifierForm'][$mfqVeggieKey]['max'] = count($newVeggieOptionsArray) - 1;
                                $menuCategory['products'][$pKey]['modifierForm'][$mfqVeggieKey]['options'] = $newVeggieOptionsArray;
                              } else {
                                // Form Options
                                $menuCategory['products'][$pKey]['modifierForm'][] = $modifierFormQuestion;
                              }
                            } else {
                              // Form Options
                              $menuCategory['products'][$pKey]['modifierForm'][] = $modifierFormQuestion;
                            }
                          // Add Modifier Class
                          } else if ($modifierClassAdd) {
                            // Form Options
                            $menuCategory['products'][$pKey]['modifierForm'][] = $modifierFormQuestion;
                          }
                        }
                        // Reorder Modifiers
                        if (!empty($menuCategory['products'][$pKey]['modifierForm'])) {
                          $sortOrder = array();
                          foreach ($menuCategory['products'][$pKey]['modifierForm'] as $key => $row) {
                            $sortOrder[$key] = $row['sort'];
                          }
                          array_multisort($sortOrder, SORT_ASC, $menuCategory['products'][$pKey]['modifierForm']);
                        }
                      }
                    }
                  }
                  // Add to menu
                  $revelMenuData['categories'][] = $menuCategory;
                }
              }
            }
            $locationData['Location']['revelMenu'] = json_encode($revelMenuData);
          }
        }
        // Update Location Data
        if (!empty($locationData)) {
          $LocationModel->id = $location['Location']['id'];
          $LocationModel->set($locationData);
          $LocationModel->save();
        }
      }
      // Return
      return true;
    } catch(PDOException $e) {
      $error = $e->getMessage();
      $error .= ' (line ' . $e->getLine() . ' in ' . $e->getFile() . ')' . PHP_EOL . $e->getTraceAsString();
      CakeLog::write('revel_systems_sync_error', $error);
      return false;
    }
  }

}
